class Counter {
  var counter: int
  var maximum: int

  invariant 0 <= counter
  invariant counter <= maximum

  constructor(max: int)
    requires max >= 0
    ensures maximum == max
    ensures counter == 0
  {
    maximum := max;
    counter := 0;
  }

  method Increment()
    modifies this
    ensures maximum == old(maximum)
    ensures counter == (if old(counter) < old(maximum) then old(counter) + 1 else old(counter))
  {
    if counter < maximum {
      counter := counter + 1;
    }
  }

  method Reset()
    modifies this
    ensures maximum == old(maximum)
    ensures counter == 0
  {
    counter := 0;
  }
}
