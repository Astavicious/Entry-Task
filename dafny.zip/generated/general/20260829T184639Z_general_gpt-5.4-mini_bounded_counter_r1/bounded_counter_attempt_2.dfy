class Counter {
  var counter: nat
  var maximum: nat

  predicate Valid()
    reads this
  {
    counter <= maximum
  }

  constructor (max: nat)
    ensures Valid()
    ensures counter == 0
    ensures maximum == max
  {
    counter := 0;
    maximum := max;
  }

  method Increment()
    requires Valid()
    modifies this
    ensures Valid()
    ensures old(counter) < maximum ==> counter == old(counter) + 1
    ensures old(counter) >= maximum ==> counter == old(counter)
  {
    if counter < maximum {
      counter := counter + 1;
    }
  }

  method Reset()
    requires Valid()
    modifies this
    ensures Valid()
    ensures counter == 0
  {
    counter := 0;
  }
}
